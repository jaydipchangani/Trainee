let startTime = null;
let activeAIWebsite = null;
let aiUsageData = {};

// List of AI websites to track
const AI_SITES = ["chat.openai.com", "bard.google.com", "gemini.google.com"];

// Function to start tracking time
function startTracking(url) {
    activeAIWebsite = url;
    startTime = Date.now();
}

// Function to stop tracking and store time
function stopTracking() {
    if (startTime && activeAIWebsite) {
        let endTime = Date.now();
        let duration = endTime - startTime;

        let today = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
        chrome.storage.local.get([today], function (result) {
            let data = result[today] || {
                aiTime: 0,
                aiUsage: {},
                lastAIUsed: {},
                tabsClosed: 0,
                tabsOpened: 0,
                totalTime: 0
            };

            data.aiTime += duration;
            data.totalTime += duration;
            data.aiUsage[activeAIWebsite] = (data.aiUsage[activeAIWebsite] || 0) + duration;
            data.lastAIUsed = { timestamp: endTime, website: activeAIWebsite };

            let update = {};
            update[today] = data;
            chrome.storage.local.set(update);
        });

        startTime = null;
        activeAIWebsite = null;
    }
}

// Detect tab switching
chrome.tabs.onActivated.addListener(activeInfo => {
    chrome.tabs.get(activeInfo.tabId, function (tab) {
        if (tab && tab.url) {
            let hostname = new URL(tab.url).hostname;
            if (AI_SITES.some(site => hostname.includes(site))) {
                stopTracking(); // Stop previous tracking
                startTracking(hostname); // Start new tracking
            } else {
                stopTracking();
            }
        }
    });
});

// Detect tab close
chrome.tabs.onRemoved.addListener(() => {
    stopTracking();
});

// Detect tab updates (page refresh)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
        let hostname = new URL(tab.url).hostname;
        if (AI_SITES.some(site => hostname.includes(site))) {
            stopTracking();
            startTracking(hostname);
        } else {
            stopTracking();
        }
    }
});
