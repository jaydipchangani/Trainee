﻿namespace Task9.Models
{
    public class RefreshRequest
    {
        public string RefreshToken { get; set; }
    }
}
